package fpoly;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestClass2 {
	@Test
	public void c1() {
	}

	@Test
	public void c2() {
	}

	@Test
	public void c3() {
	}

	@Test
	public void c4() {
		Assert.assertFalse(false);
	}
}
